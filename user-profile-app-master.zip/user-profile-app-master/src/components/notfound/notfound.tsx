import React from 'react'

const NotFound = () => <h1>Not found</h1>
export default NotFound
